-keep public class com.google.android.gms.ads.** {
   public *;
}
-keep public class com.studyquizmaster.app.MainActivity$WebAppInterface {
    public *;
}
